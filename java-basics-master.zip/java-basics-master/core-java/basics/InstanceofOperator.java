package basics;

public class InstanceofOperator {

	public static void main(String[] args) {
		Integer i = null;
		Integer j = 10;
		
		System.out.println(i instanceof Integer);
		System.out.println(j instanceof Integer);
	}
}
