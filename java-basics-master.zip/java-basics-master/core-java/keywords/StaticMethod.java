package keywords;

public class StaticMethod {

	static void display() {
		System.out.println("Static Method called !");
	}
	public static void main(String[] args) {
		// Calling method without creating any object of class
		display();
	}

}
